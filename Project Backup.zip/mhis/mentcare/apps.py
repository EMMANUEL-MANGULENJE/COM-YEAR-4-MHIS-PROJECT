from django.apps import AppConfig


class MentcareConfig(AppConfig):
    name = 'mentcare'
    