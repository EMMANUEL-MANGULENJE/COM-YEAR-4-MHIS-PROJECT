# from django.urls import path
# from django.contrib.auth import views as auth_views # importing login and logout views] 
# from . import views
# app_name ='mentcare'


# urlpatterns = [
#     path('', views.home, name ='home'),
#     path('register/', views.register, name = 'register'),
#     path('patientDetail/', views.patientDetail, name = 'patientDetail'),
#     path('NurseNotes/', views.NurseNotes, name = 'NurseNotes'),
#     path('DoctorNotes/', views.DoctorNotes, name = 'DoctorNotes'),
#     path('PatientAdd/', views.PatientAdd, name = 'PatientAdd'),
#      path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),#login route
#     path('logout/', auth_views.LogoutView.as_view(template_name='logout.html'), name='logout'),#logout route

# ]
